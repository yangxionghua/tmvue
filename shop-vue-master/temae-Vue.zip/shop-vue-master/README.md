# shop_vue
a shop made with Vue

# 源码项目说明:
	shop_client  客户端应用
	shop-server  服务器端应用



## 1. 准备
	    确保安装了node环境
		查看是否已经安装: node -v

## 2. 启动后台应用
	1). 进入shop_server
	2). 执行命令: npm start

## 3. 启动前台应用并访问
	1). 进入shop_client 
	2). 执行命令: npm start/npm run dev
